# Creo las variables
str_Nombre = 'Juan'
str_Apellido = 'Perez'
(int_Edad) = 30
int_Teléfono = 2323123456
bool_Casado = False
bool_Con_Hijos = True
list_Amigos = ['Pedro', 'Ana', 'Verónica', 'Franco']
dic_Películas_Vistas = {
    'key1': 'Rambo',
    'key2': 'Misión Imposible',
    'key3': 'Top Gun',
    'key4': 'Titanic'
}
# Imprimo en consola
print(str_Nombre)
print(str_Apellido)
print(int_Edad)
print(int_Teléfono)
print(bool_Casado)
print(bool_Con_Hijos)
print(list_Amigos)
print(dic_Películas_Vistas)

