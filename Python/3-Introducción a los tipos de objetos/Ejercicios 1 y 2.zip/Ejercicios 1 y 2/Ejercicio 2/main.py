float_Peso = input("Peso(KG): ") # Peso en Kilogramos
float_Estatura = input("Estatura(metros): ") # Altura en metros
float_IMC = round(float(float_Peso)/float(float_Estatura)**2,2) # Cálculo del índice de masa corporal
print("Tu índice de masa corporal es " + str(float_IMC))

